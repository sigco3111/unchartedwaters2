#!/bin/bash
set -e
cp /tmp/payload/Game.tsx src/components/Game.tsx
cp /tmp/payload/package.json package.json
rm -f src/components/1-Game.tsx 2-package.json
