#!/bin/bash
set -e
cp /tmp/payload/src/components/Game.tsx src/components/Game.tsx
cp /tmp/payload/package.json package.json
cp /tmp/payload/package-lock.json package-lock.json
echo "applied v1.0.2 save-persistence fix"
