#!/bin/bash
set -e
cp -rf /tmp/payload/src/* src/
cp -f /tmp/payload/package.json /tmp/payload/package-lock.json /tmp/payload/README.md .
rm -f 7-payload3.zip
