#!/bin/bash
set -e
cd "$GITHUB_WORKSPACE"
for f in package.json package-lock.json README.md src/components/Game.tsx; do
  mkdir -p "$(dirname "$f")"
  cp "/tmp/payload/$f" "$f"
done
rm -f ./*payload.zip
