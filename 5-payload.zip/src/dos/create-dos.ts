/* eslint-disable @typescript-eslint/no-explicit-any */
import { once, load } from "nano-loader";

const loadJsDos = once(() => load(`${import.meta.env.BASE_URL}static/js-dos/js-dos.js`));

export async function createDos(
  canvas: HTMLCanvasElement,
): Promise<{ fs: any; main: any }> {
  await loadJsDos();

  return await new Promise((resolve) => {
    window
      .Dos(canvas, {
        wdosboxUrl: `${import.meta.env.BASE_URL}static/js-dos/wdosbox.js`,
        SDL_numSimultaneouslyQueuedBuffers: 10,
      } as Record<string, unknown>)
      .ready((fs, main) => resolve({ fs, main }));
  });
}

export function applyMove(elem: HTMLDivElement, consumer: any) {
  window.DosController.Move(elem, consumer);
}
