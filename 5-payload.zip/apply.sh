#!/bin/bash
set -e
cd "$GITHUB_WORKSPACE"
for f in vite.config.ts index.html README.md README.upstream.md src/dos/create-dos.ts src/components/Game.tsx src/components/Splash.tsx src/types/vite-env.d.ts; do
  mkdir -p "$(dirname "$f")"
  cp "/tmp/payload/$f" "$f"
done
rm -f CNAME
rm -f ./*payload.zip
